Inspired by gamefying my practice sessions:
 a simple, lightweight html groove randomizer with a built in metronome to help you train using your grooves on different tempo

  find it on
    https://insertclevernamehere.github.io/Drums-Trainer-test/
